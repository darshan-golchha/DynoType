function PictureBox() {
  return <img />;
}

export default PictureBox;
