import React from "react";

let typedWordCount = 0;
let wrongWordCount = 0;
let startTime = Date.now();
let timeElapsed = 0;

function TextContainer(props: {
  onResetTimer: () => void;
  onStartTimer: () => void;
}) {
  let [importedText, setImportedText] = React.useState(
    `dose sentiment betray knot stunning angel pause original snub unrest drain damn wrong digital waste mud lost direction thank seem fever dialogue miscarriage voyage password dull float gate conspiracy match joystick selection arena mosque banner tear blame run resort manner throat skeleton hand publication privacy grand fraud mature father kidnap district dawn boat week pledge suit romantic process runner movement population domination manager raw nose print diplomat exemption presentation infection technique escape shock girl addition fuel raise month owner preference`
  );

  //typed text
  let [text, setText] = React.useState("");

  let [index, setIndex] = React.useState(0);

  let [wrong, setWrong] = React.useState(0);

  function keyDownHandler(event: KeyboardEvent) {
    if (event.key === "Backspace") {
      if (index === 0) return;
      setText(text.slice(0, -1));
      setIndex(index - 1);
      if (wrong > 0) {
        setWrong(wrong - 1);
      }
      return;
    }

    setText(text + event.key);
    setIndex(index + 1);
    if (event.key === importedText[index]) {
      console.log("correct: " + event.key);
      if (wrong > 0) setWrong(wrong + 1);
    } else {
      console.log(
        "incorrect: " + event.key + " instead of: " + importedText[index]
      );
      setWrong(wrong + 1);
    }
  }

  function classString(letterIndex: number) {
    if (letterIndex >= index - wrong && letterIndex < index) {
      return "letter wrongLetter";
    } else if (letterIndex < index) {
      return "letter typedLetter";
    } else if (letterIndex === index) {
      return "letter currentLetter";
    } else {
      return "letter";
    }
  }

  let displayText = importedText.split("").map((letter, index) => {
    if (letter === " ") {
      return (
        <div className={classString(index)} key={index}>
          &nbsp;
        </div>
      );
    } else {
      return (
        <div className={classString(index)} key={index}>
          {letter}
        </div>
      );
    }
  });

  let rows = [];
  for (let i = 0; i < displayText.length; i += 110) {
    rows.push(displayText.slice(i, i + 110));
  }

  React.useEffect(() => {
    addEventListener("keydown", keyDownHandler);

    return () => {
      removeEventListener("keydown", keyDownHandler);
    };
  }, [text]);

  React.useEffect(() => {
    const interval = setInterval(() => {
      const letterElements = document.getElementsByClassName("typedLetter");
      typedWordCount = 0;
      for (let i = 0; i < letterElements.length; i++) {
        if (letterElements[i].innerHTML === "&nbsp;") {
          typedWordCount++;
        }
      }

      const wrongLetterElements =
        document.getElementsByClassName("wrongLetter");
      wrongWordCount = 0;
      for (let i = 0; i < wrongLetterElements.length; i++) {
        if (wrongLetterElements[i].innerHTML === "&nbsp;") {
          wrongWordCount++;
        }
      }

      console.log("Typed: " + typedWordCount);
      console.log("Wrong: " + wrongWordCount);

      timeElapsed = Date.now() - startTime;
    }, 1000);

    return () => clearInterval(interval);
  }, []);

  function resetTimer() {
    startTime = Date.now();
    timeElapsed = 0;
    typedWordCount = 0;
    wrongWordCount = 0;
    setText("");
    setIndex(0);
    setWrong(0);
    props.onResetTimer();
  }

  function startTimer() {
    resetTimer();
    props.onStartTimer();
  }

  return (
    <>
      <div>
        <div className="letterTable">
          {rows.map((row, index) => {
            return (
              <div className="letterRow" key={index}>
                {row}
              </div>
            );
          })}
        </div>
      </div>

      <button className="btn btn-primary" onClick={startTimer}>
        Start
      </button>
      <button className="btn btn-danger" onClick={resetTimer}>
        Reset
      </button>
    </>
  );
}

export default TextContainer;
