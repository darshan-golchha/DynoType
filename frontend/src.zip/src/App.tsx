import { useState, useEffect } from "react";
import "./App.css";
import PictureBox from "./components/PictureBox";
import TextContainer from "./components/TextContainer";
import DinoChaser from "./components/Dino";
import DinoPray from "./components/DinoPray";
import Road from "./components/Road";
import "bootstrap/dist/css/bootstrap.css";

function App() {
  const [time, setTime] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setTime((prevTime) => prevTime + 1);
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  const formattedTime = new Date(time * 1000).toISOString().substr(14, 5);

  function suspendClock() {}

  function startClock() {}

  return (
    <>
      <div className="Dino">
        <h1 className="title">DinoType</h1>
        <div className="animation">
          <DinoChaser />
          <DinoPray speed={60} />
        </div>
        <Road width={1000} bottom={1000} />
      </div>
      <header className="timer">
        <h1>{formattedTime}</h1>
      </header>
      <header className="speedDisplay">Typing Speed: 0 WPM</header>
      <TextContainer
        onResetTimer={startClock}
        onStartTimer={suspendClock}
      ></TextContainer>
    </>
  );
}

export default App;
